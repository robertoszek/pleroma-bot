window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "",
        "website" : "",
        "location" : ""
      },
      "avatarMediaUrl" : "https://abs.twimg.com/sticky/default_profile_images/default_profile.png",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1320506197913542656/1604883750"
    }
  }
]