window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "1320506197913542656"
    }
  }
]