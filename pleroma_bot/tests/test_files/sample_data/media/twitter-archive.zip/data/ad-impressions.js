window.YTD.ad_impressions.part0 = [

]
