window.YTD.ad_impressions.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer reviews"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Education news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tech news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Space and astronomy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Government"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Weather"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Science news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music festivals and concerts"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sporting events"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-10 23:32:40"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer reviews"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Education news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tech news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Space and astronomy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Government"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Weather"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Science news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music festivals and concerts"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sporting events"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-10 23:30:00"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Action sports"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Comedy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Dogs"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sci-fi and fantasy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sports themed"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-10 23:28:16"
            },
            {
              "impressionTime" : "2021-12-10 23:37:53",
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Guangzhou China",
                "screenName" : "@Guangzhou_City"
              }
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Action sports"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Comedy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Dogs"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sci-fi and fantasy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sports themed"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-12 17:10:33"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "BYBIT 🦍",
                "screenName" : "@Bybit_Official"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tech news"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2021-12-12 17:02:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Action sports"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Comedy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Dogs"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sci-fi and fantasy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sports themed"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-12 17:11:29"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Frederic Beeg",
                "screenName" : "@fredericbeeg"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-12 17:10:26"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Action sports"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Comedy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Dogs"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sci-fi and fantasy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sports themed"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-12 17:10:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer reviews"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Education news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tech news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Space and astronomy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Government"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Weather"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Science news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music festivals and concerts"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sporting events"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-12 17:05:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Action sports"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Comedy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Dogs"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sci-fi and fantasy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sports themed"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-12 17:11:09"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "nac Image Technology",
                "screenName" : "@nacImageTech"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Men"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-12 17:02:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Frederic Beeg",
                "screenName" : "@fredericbeeg"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-12 17:11:09"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "WorldSkills Poland - liderzy branż",
                "screenName" : "@WorldSkillsPL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 to 54"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2021-12-12 17:06:19"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-13 19:07:22"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Frederic Beeg",
                "screenName" : "@fredericbeeg"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-13 17:46:48"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "SearchTweets",
              "promotedTweetInfo" : {
                "tweetId" : "1465798142322958336",
                "tweetText" : "Doing easy, simple, repetitive tasks can sometimes trick our brains into feeling the reward of productivity rather than actually getting high value work done.\n\nRead the full article ▸ https://t.co/5OycDyUeAH\n\n#Productivity #Mindful #FutureOfWork",
                "urls" : [
                  "https://t.co/5OycDyUeAH"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Taskable",
                "screenName" : "@TaskableHQ"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2021-12-13 17:46:49"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 09:56:16"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 09:55:46"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 09:56:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 09:55:46"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:20:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Action sports"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Comedy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Dogs"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sci-fi and fantasy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sports themed"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:22:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Action sports"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Comedy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Dogs"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sci-fi and fantasy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sports themed"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:12:47"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:38:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Action sports"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Comedy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Dogs"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sci-fi and fantasy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sports themed"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:38:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:12:45"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Action sports"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Comedy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Dogs"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sci-fi and fantasy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sports themed"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:20:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:37:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "eToroPL",
                "screenName" : "@eToroPL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:37:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer reviews"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Education news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tech news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Space and astronomy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Government"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Weather"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Science news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music festivals and concerts"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sporting events"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:24:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Action sports"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Comedy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Dogs"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sci-fi and fantasy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sports themed"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:20:31"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "eToroPL",
                "screenName" : "@eToroPL"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:25:01"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:24:51"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:20:06"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Action sports"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Comedy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Dogs"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sci-fi and fantasy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sports themed"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:25:02"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:22:17"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Action sports"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Comedy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Dogs"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sci-fi and fantasy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sports themed"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:03:22"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Action sports"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Comedy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Dogs"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sci-fi and fantasy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sports themed"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:35:40"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer reviews"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Education news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tech news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Space and astronomy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Government"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Weather"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Science news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music festivals and concerts"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sporting events"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:18:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:18:44"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 10:35:39"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer reviews"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Education news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tech news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Space and astronomy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Government"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Weather"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Science news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music festivals and concerts"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sporting events"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 12:34:58"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Huawei",
                "screenName" : "@Huawei"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer reviews"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Education news and general info"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tech news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Space and astronomy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Government"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Weather"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Science news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Music festivals and concerts"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Sporting events"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210218"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list20210118"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "Exclude audience list"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 12:34:59"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Capgemini Business Services",
                "screenName" : "@CapgeminiBusSvc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tech news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 17:31:38"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Capgemini Business Services",
                "screenName" : "@CapgeminiBusSvc"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tech news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 17:31:39"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 11:04:04"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "Poland"
                }
              ],
              "impressionTime" : "2021-12-15 11:04:04"
            }
          ]
        }
      }
    }
  }
]