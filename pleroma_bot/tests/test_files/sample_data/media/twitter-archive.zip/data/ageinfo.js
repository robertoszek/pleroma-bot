window.YTD.ageinfo.part0 = [
  {
    "ageMeta" : {
      "ageInfo" : {
        "age" : [
          "52"
        ],
        "birthDate" : "1969-01-01"
      }
    }
  }
]