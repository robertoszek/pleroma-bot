window.YTD.ni_devices.part0 = [
  {
    "niDeviceResponse" : {
      "messagingDevice" : {
        "deviceType" : "Full",
        "carrier" : "orange_es",
        "phoneNumber" : "+34616872515",
        "createdDate" : "2020.10.25"
      }
    }
  }
]