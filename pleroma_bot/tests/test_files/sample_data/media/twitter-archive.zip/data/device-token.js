window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "2PytrUI3Q7fIoVzoWddOwzWNacytTvGteOWGVx3V",
      "createdAt" : "2021-09-28T19:24:24.437Z",
      "lastSeenAt" : "2021-12-15T10:03:21.878Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "SNAOMYcnzR8FX7dZcLuzZM2qPlSHJOUBVGdyM8Qj",
      "createdAt" : "2021-12-23T21:44:44.988Z",
      "lastSeenAt" : "2021-12-23T21:44:44.990Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]