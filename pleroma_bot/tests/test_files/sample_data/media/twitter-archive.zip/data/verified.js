window.YTD.verified.part0 = [
  {
    "verified" : {
      "accountId" : "1320506197913542656",
      "verified" : false
    }
  }
]