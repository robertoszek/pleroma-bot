window.YTD.connected_application.part0 = [
  {
    "connectedApplication" : {
      "organization" : {
        "name" : ""
      },
      "name" : "pleroma-test",
      "description" : "This app was created to use the Twitter API.",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2021-12-10T23:45:40.000Z",
      "id" : "19988133"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter",
        "url" : "https://twitter.com"
      },
      "name" : "Twitter Discourse Forums",
      "description" : "Twitter Developer Forums",
      "permissions" : [
        "read"
      ],
      "approvedAt" : "2021-05-12T12:47:16.000Z",
      "id" : "6819138"
    }
  }
]