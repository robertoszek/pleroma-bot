window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "tabulacion@protonmail.com",
      "createdVia" : "oauth:3033300",
      "username" : "BotPleroma",
      "accountId" : "1320506197913542656",
      "createdAt" : "2020-10-25T23:23:13.924Z",
      "accountDisplayName" : "test-pleroma-bot"
    }
  }
]