window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "test@test.com",
      "createdVia" : "oauth:12345678",
      "username" : "BotPleroma",
      "accountId" : "1234567890123456789",
      "createdAt" : "2020-10-25T23:23:13.924Z",
      "accountDisplayName" : "test-pleroma-bot"
    }
  }
]
