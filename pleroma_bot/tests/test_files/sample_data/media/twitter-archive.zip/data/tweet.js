window.YTD.tweet.part0 = [
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "3"
      ],
      "favorite_count" : "0",
      "id_str" : "1470078041024049154",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1470078041024049154",
      "created_at" : "Sun Dec 12 17:08:12 +0000 2021",
      "favorited" : false,
      "full_text" : "Yep",
      "lang" : "und"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "2"
      ],
      "favorite_count" : "0",
      "id_str" : "1470077585950396427",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1470077585950396427",
      "created_at" : "Sun Dec 12 17:06:23 +0000 2021",
      "favorited" : false,
      "full_text" : "Yo",
      "lang" : "und"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "2"
      ],
      "favorite_count" : "0",
      "id_str" : "1470076528910385154",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1470076528910385154",
      "created_at" : "Sun Dec 12 17:02:11 +0000 2021",
      "favorited" : false,
      "full_text" : "Ye",
      "lang" : "und"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "1"
      ],
      "favorite_count" : "0",
      "id_str" : "1469451661605314566",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1469451661605314566",
      "created_at" : "Fri Dec 10 23:39:11 +0000 2021",
      "favorited" : false,
      "full_text" : "🔒",
      "lang" : "und"
    }
  },
  {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/BotPleroma/status/1474760145850806283/video/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "http://pbs.twimg.com/ext_tw_video_thumb/1474759982616924161/pr/img/uH3f1q4RhFyuzuDf.jpg",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1474759982616924161/pr/img/uH3f1q4RhFyuzuDf.jpg",
            "id_str" : "1474759982616924161",
            "id" : "1474759982616924161",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1474759982616924161/pr/img/uH3f1q4RhFyuzuDf.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/JE657bS9lf"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "0",
      "id_str" : "1474760145850806283",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1474760145850806283",
      "possibly_sensitive" : false,
      "created_at" : "Sat Dec 25 15:13:13 +0000 2021",
      "favorited" : false,
      "full_text" : "http://cutt.ly/xg3TuYA",
      "lang" : "und",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/BotPleroma/status/1474760145850806283/video/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://t.co/JE657bS9lf",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1474759982616924161/pr/img/uH3f1q4RhFyuzuDf.jpg",
            "id_str" : "1474759982616924161",
            "video_info" : {
              "aspect_ratio" : [
                "16",
                "9"
              ],
              "duration_millis" : "16789",
              "variants" : [
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1474759982616924161/pr/pl/rMZAIQHjgxQCfNIL.m3u8?tag=12&container=fmp4"
                },
                {
                  "bitrate" : "256000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1474759982616924161/pr/vid/480x270/CMszGWR7c_LrQXFp.mp4?tag=12"
                },
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1474759982616924161/pr/vid/640x360/9F3vPy31VrXPajYo.mp4?tag=12"
                },
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1323049175848833033/pu/vid/1280x720/de6uahiosn3VXMZO.mp4?tag=10"
                }
              ]
            },
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1474759982616924161",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1474759982616924161/pr/img/uH3f1q4RhFyuzuDf.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "display_url" : "pic.twitter.com/JE657bS9lf"
          }
        ]
      }
    }
  }, {
    "tweet" : {
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://pbs.twimg.com/media/ElxpP0hXEAI9X-H.jpg",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://pbs.twimg.com/media/ElxpP0hXEAI9X-H.jpg",
            "media_url" : "https://pbs.twimg.com/media/ElxpP0hXEAI9X-H.jpg",
            "id_str" : "1474762157522919438",
            "id" : "1474762157522919438",
            "media_url_https" : "https://pbs.twimg.com/media/ElxpP0hXEAI9X-H.jpg",
            "sizes" : {
              "medium" : {
                "w" : "600",
                "h" : "600",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "600",
                "h" : "600",
                "resize" : "fit"
              },
              "small" : {
                "w" : "600",
                "h" : "600",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "https://pbs.twimg.com/media/ElxpP0hXEAI9X-H.jpg"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "0",
      "id_str" : "1474762178414665732",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1474762178414665732",
      "possibly_sensitive" : false,
      "created_at" : "Sat Dec 25 15:21:17 +0000 2021",
      "favorited" : false,
      "full_text" : "https://twitter.com/BotPleroma/status/1323048312161947650/photo/1",
      "lang" : "und",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/BotPleroma/status/1323048312161947650/photo/1",
            "indices" : [
              "0",
              "23"
            ],
            "url" : "https://twitter.com/BotPleroma/status/1323048312161947650/photo/1",
            "media_url" : "https://twitter.com/BotPleroma/status/1323048312161947650/photo/1",
            "id_str" : "1474762157522919438",
            "id" : "1474762157522919438",
            "media_url_https" : "https://twitter.com/BotPleroma/status/1323048312161947650/photo/1",
            "sizes" : {
              "medium" : {
                "w" : "600",
                "h" : "600",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "600",
                "h" : "600",
                "resize" : "fit"
              },
              "small" : {
                "w" : "600",
                "h" : "600",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "https://twitter.com/BotPleroma/status/1323048312161947650/photo/1"
          }
        ]
      }
    }
  }
]
