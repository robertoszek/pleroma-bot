window.YTD.protected_history.part0 = [
  {
    "protectedHistory" : {
      "protectedAt" : "2021-12-10T23:37:50.000Z",
      "action" : "Protect"
    }
  }
]