window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "My bio text.\nMultiple lines,\neven.",
        "website" : "",
        "location" : ""
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1475115223581446156/LiX6gsld.jpg",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1320506197913542656/1640648998"
    }
  }
]