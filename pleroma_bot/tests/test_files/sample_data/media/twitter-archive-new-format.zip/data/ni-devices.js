window.YTD.ni_devices.part0 = [

]
