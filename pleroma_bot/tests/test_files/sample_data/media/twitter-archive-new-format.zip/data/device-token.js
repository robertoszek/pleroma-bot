window.YTD.device_token.part0 = [

]
